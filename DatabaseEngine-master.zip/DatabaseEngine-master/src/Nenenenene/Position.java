package Nenenenene;

import java.io.Serializable;

public class Position implements Serializable {

    int i;
    String pagename;

    public Position(int x, String y) {
        i = x;
        pagename = y;
    }
    //public Position(int x) {
    //i=x;
    //}

}
